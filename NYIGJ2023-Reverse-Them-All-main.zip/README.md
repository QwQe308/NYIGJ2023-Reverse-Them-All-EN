# NYIGJ2023-Reverse-Them-All<br>
A jam game made for New Year Incremental Game Jam 2023(Theme: Capped at 1).<br>
Do not play this junk, gotta play Antimatter Dimensions instead(what)<br>
Thanks to 凌洛, for giving me the idea of reversing time.<br>
Thanks to 3^3=7, for translating my game into English.